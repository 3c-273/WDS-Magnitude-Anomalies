#! /usr/bin/perl -w
# Check the WDS listed magnitudes aganist the data in the 2MASS, PPMXL,
# Tycho, UCAC4, and URAT1 catalogs.

use lib "/work/astro/utilities";

use astroUtils;
use strict;

my $start = time;

my $pi = 3.14159265358979323846;
my $d2r = $pi / 180; # Degrees to radians.
my $tpi = $pi  * 2;
my $oneArcMin = $pi / (180 * 60); # 1 arc minute in radians.
my $r2d = 180 / $pi; # Radians to degrees.
my $tenArcSec = $oneArcMin / 6; # 10 arc seconds in radians.

# Create an array of the files containg the catalog data.
my $minDeg = 999;
my $maxDeg = -999;
my @sdFile;
my $sqDegDir = "/work/astro/wds/magnitudeStudy/squareDegrees";
chdir $sqDegDir;

my $anomaly = "/work/astro/wds/magnitudeStudy/results/anomalies.txt";
open AN, ">$anomaly" or die "Couldn't open $anomaly.\n";
print AN "WDS ID     Discover       RA            Dec       mva-mvb       ",
         " Rho    Theta   dmv  Cmnt\n";

my $nrbyAn = "/work/astro/wds/magnitudeStudy/results/nearbyAnomalies.txt";
open NAN, ">$nrbyAn" or die "Couldn't open $nrbyAn.\n";

my $narrow = "/work/astro/wds/magnitudeStudy/results/under10sec.txt";
open NRRW, ">$narrow" or die "Couldn't open $narrow.\n";
print NRRW "WDS ID     Discover       RA            Dec       mva-mvb       ",
          " Rho    Theta   dmv  Cmnt\n";

my $nearby = "/work/astro/wds/magnitudeStudy/results/nearby.txt";
open NRBY, ">$nearby" or die "Couldn't open $nearby.\n";
print NRBY "WDS ID     Discover\n",
           "  Catalog Catalog ID            RA        Dec         mv     R\n";

my $note = "/work/astro/wds/magnitudeStudy/results/wdsNoteStars.txt";
open NOTE, ">$note" or die "Couldn't open $note.\n";
print NOTE "WDS ID     Discover\n",
           "  Catalog Catalog ID            RA        Dec         mv     R\n";

my $notFound = "/work/astro/wds/magnitudeStudy/results/notFound.txt";
open NF, ">$notFound" or die "Couldn't open $notFound.\n";
print NF "WDS ID     Discover       RA            Dec       mva-mvb       ",
         " Rho    Theta\n";

my $preciseMv = "/work/astro/wds/magnitudeStudy/results/preciseMv.txt";
open PM, ">$preciseMv" or die "Couldn't open $preciseMv.\n";
print PM "WDS ID     Discover\n",
         "  Catalog Catalog ID            RA        Dec         mv     R\n";

my $susNear = "/work/astro/wds/magnitudeStudy/results/nearbySuspect.txt";
open NR_SUS, ">$susNear" or die "Couldn't open $susNear.\n";
print NR_SUS "WDS ID     Discover\n",
             "  Catalog Catalog ID            RA        Dec         mv     R\n";

my $suspect = "/work/astro/wds/magnitudeStudy/results/suspect.txt";
open SPT, ">$suspect" or die "Couldn't open $suspect.\n";
print SPT "WDS ID     Discover       RA            Dec       mva-mvb       ",
          " Rho    Theta   dmv  Cmnt\n";

my $wide = "/work/astro/wds/magnitudeStudy/results/above10sec.txt";
open WIDE, ">$wide" or die "Couldn't open $wide.\n";
print WIDE "WDS ID     Discover       RA            Dec       mva-mvb       ",
          " Rho    Theta   dmv  Cmnt\n";

# Read and process the WDS data.
my $cnfmdCt = 0;   # Count of the pairs confirmed by a catalog entry.
my $nrbyCt = 0;    # Count of the stars found near a binary.
my @file;          # Files to search for catalog data for the binary.
my $nfCt = 0;      # Count of the pairs where no catalog star was found.
my $rejectCt = 0;  # Number of WDS pairs rejected.
my $susCt = 0;     # Count of the suspect.
my $wdsLineCt = 0; # Count of the lines in the WDS.

my $wdsPrecise = "/work/astro/data/wds/wds_precise.txt";
open WDS, "$wdsPrecise" or die "Can't open $wdsPrecise.\n";
while (<WDS>) {
  $wdsLineCt++;

  # if ($wdsLineCt > 4000) { print "Ending early.\n"; last; } #TEST

  my $wdsId = substr($_, 0, 10);
  my $dsc = substr($_, 10, 13);
  trim($dsc);
  $dsc =~ s/\s+/ /g;

  my $mva = substr($_, 58, 5);
  $mva =~ s/\s+//g;

  # If there's no primary magnitude, reject the pair.
  if ($mva !~ /\d+/) {
    $rejectCt++;
    next;
  }

  # The catalogs are not complete under 17mv or above 6.0mv.
  if (($mva >= 17.0) or ($mva < 6.0)) {
    $rejectCt++;
    next;
  }

  # Ignore problem pairs.
  if (substr($_, 107, 4) =~ /[X|I|K|R]/) {
    $rejectCt++;
    next;
  }

  my $pa = substr($_, 38, 7);
  $pa =~ s/\s+//g;
  my $sep = substr($_, 46, 8);
  $sep =~ s/\s+//g;

  my $mvb = substr($_, 64, 5);
  $mvb =~ s/\s+//g;

  unless (defined($mvb)) { $mvb = "Unknown"; }

  my $wdsNote = 0;
  if (substr($_, 107, 4) =~ /N/) { $wdsNote = "N"; }

  # Get the double's coordinates and establish an error box around it. Any
  # stars in the catalog within that box will be considered.
  my $sign = substr($_, 121, 1);
  my $d = substr($_, 122, 2);

  # If there are no precise coordinate, reject the star.
  unless ($d =~ /\d+/) {
    $rejectCt++;
    next;
  }

  my $mvRange = 1; # Tolerance for mv difference between WDS and catalog mv.
  if ($mva =~ /\d+\.\d{2}/) { $mvRange = 0.5; }

  my $m = substr($_, 124, 2);
  my $s = substr($_, 126, 4);

  unless ($s =~ /\d+/) { $s = 1e-99; }
  my $dec = ($d + ($m / 60) + ($s / 3600)) * $d2r;

  if ($sign eq "-") { $dec *= -1; }
  my $maxDec = $dec + $tenArcSec;
  my $minDec = $dec - $tenArcSec;

  my $h = substr($_, 112, 2);
  $m = substr($_, 114, 2);
  $s = substr($_, 116, 2);
  my $ss  = substr($_, 118, 3);
  unless ($ss =~ /\d+/) { $ss = 0; }
  my $ra = ($h + ($m / 60) + (($s + $ss) / 3600)) * 15 * $d2r;

  my $raE = $tenArcSec / cos($dec);

  my $maxRa = $ra + $raE;
  my $minRa = $ra - $raE;

  # Determine which square degree files to search based on the ra and dec min
  # and max points.
  @file = ();

  my $deg1;
  my $deg2;
  if ($dec < 0) { 
    $deg1 = int($minDec * $r2d) + 89;
    $deg2 = int($maxDec * $r2d) + 89;
  } else {
    $deg1 = int($minDec * $r2d) + 90;
    $deg2 = int($maxDec * $r2d) + 90;
  }

  if ($deg1 == 0) { $deg1 = 1; }
  if ($deg2 == 0) { $deg2 = 1; }

  my $fCt = 0;
  if ($deg1 == $deg2) {
    $fCt = getSD($fCt, $minRa, $maxRa, $dec);
  } else {
    $fCt = getSD($fCt, $minRa, $maxRa, $dec);
    $fCt = getSD($fCt, $minRa, $maxRa, $dec);
  }

  # Get stars from the catalogs that are within the above error box. 
  $nrbyCt = 0;
  my $deltaMv = 99;
  my $ok = 0;
  my @nrbyStars = ();

  for (my $i = 0; $i < $fCt; $i++) {
    open FILE, $file[$i] or die "Can't open file $file[$i].\n";
    while (<FILE>) {
      my @a = split /\|/, $_;
      if ($a[0] < $minRa) {
        next;
      } elsif ($a[0] > $maxRa) {
        last;
      }

      if (($a[0] > $minRa) and ($a[0] < $maxRa)) {
        my $dm = abs($a[2] - $mva);
        my $dRa = ($ra - $a[0]) * cos($dec);
        my $dDec = $dec - $a[1];
        my $r = sqrt(($dRa * $dRa) + ($dDec * $dDec));

        if ($r < $tenArcSec) {
          if ($dm < $mvRange) {
            # The WDS magnitudes have been confirmed.
            $cnfmdCt++;
            $ok = 1;
            last;
          } elsif ($mvb =~ /\d+/) {
            my $m1 = $mva;
            my $m2 = $mvb;

            if ($m1 > $m2) {
              my $i = $m1;
              $m1 = $m2;
              $m2 = $i;
            }
            my $exp = ($m1 - $m2) / 2.5;
            my $a = 10**$exp;
            my $b = log(1 + $a);
            my $c = 2.5 * ($b / log(10)); 
            my $combinedMv = $m1 - $c;
            $dm = abs($a[2] - $combinedMv);
            if ($dm < $mvRange) {
              # The WDS magnitudes have been confirmed.
              $cnfmdCt++;
              $ok = 1;
              last;
            }
          }

          if ($ok == 0) {
            my $i = " " .  r3($r * 3600 / $d2r) . "|" . $_  . "\n";
            push @nrbyStars, $i;
            if ($dm < $deltaMv) { $deltaMv = $dm; }
            $nrbyCt++;
          }
        }
      }
    }
    close FILE;
  }

  if ($ok == 0) {
    # The WDS magnitudes were NOT confirmed.
    my $aRa =  r2aladinRa($ra);
    my $aDec =  r2aladinDec($dec);
    my $cmmnt = "";
    my $mvAB = "$mva-$mvb";
    $mvAB =~ s/\s+//g;
    my $nearBy = "";
    $deltaMv = r2($deltaMv);
    if (length($deltaMv) == 1) { $deltaMv = $deltaMv . ".00"; }

    while (length($aRa) < 11) { $aRa .= " "; }
    while (length($aDec) < 13) { $aDec .= " "; }
    while (length($deltaMv) < 4) { $deltaMv .= " "; }
    while (length($dsc) < 12) { $dsc .= " "; }
    while (length($mvAB) < 12) { $mvAB .= " "; }
    while (length($pa) < 7) { $pa .= " "; }
    while (length($sep) < 8) { $sep .= " "; }

    if ($nrbyCt > 0) {
      my @sorted = sort byPipe @nrbyStars;
      $suspect = 1; # Set to 0 if there is a nearby star within 4mv of $mva.
      foreach my $i (@nrbyStars) {
        my @a = split /\|/, $i;
        my $cat;
        if ($a[4] eq "2")    { $cat = "2MASS" }
        elsif ($a[4] eq "P") { $cat = "PPMXL" }
        elsif ($a[4] eq "U") { $cat = "UCAC4" }
        elsif ($a[4] eq "Z") { $cat = "URAT1" }
        elsif ($a[4] eq "T") { $cat = "Tycho" }

        if (abs($mva - $a[3]) < 4) { $suspect = 0; }

        $a[5] =~ s/^\s+//;
        while (length($a[5]) < 19) { $a[5] .= " "; } # Cat ID.
        my $coords = r2aladinRa($a[1]) . " " . r2aladinDec($a[2]);
        while (length($coords) < 24) { $coords .= " "; }
        if ($a[3] eq "30") {
          $a[3] = " Unk  ";
        } else {
          $a[3] =~ s/^\s+//;
          if ($a[3] =~ /\./) {
            while ($a[3] =~ /0$/) {
              $a[3] =~ s/0$//;
            }
          }
        }
        while (length($a[3]) < 6) { $a[3] .= " "; }  # Cat mv.

        # WdsId Discoverer Cat    Id     RA    Dec    mv dist \n";
        $nearBy .= "  $cat $a[5] $coords $a[3] $a[0]\n"
      }

      if ($suspect == 0) {
        $cmmnt = "C";
        print NRBY "$wdsId $dsc\n$nearBy";
      } else {
        $cmmnt = "S";
        print NR_SUS "$wdsId $dsc\n$nearBy";
        print SPT "$wdsId $dsc $aRa $aDec $mvAB $sep $pa $deltaMv $cmmnt\n";
        $susCt++;
      }

      print NAN "$wdsId $dsc\n$nearBy";

    } else {
      $cmmnt = "X";
      print NF "$wdsId $dsc $aRa $aDec $mvAB $sep $pa\n";
      $nfCt++;
    }

    if ($mvRange == 0.5) {
      print PM "$wdsId $dsc\n$nearBy";
      $cmmnt .= "P";
    }

    if ($wdsNote eq "N") {
      if ($nrbyCt == 0) { $nearBy = "  No nearby catalog stars found.\n"; }
      print NOTE "$wdsId $dsc\n$nearBy";
      $cmmnt .= "N";
    }

    if ($sep < 10) {
      print NRRW "$wdsId $dsc $aRa $aDec $mvAB $sep $pa $deltaMv $cmmnt\n";
    } else {
      print WIDE "$wdsId $dsc $aRa $aDec $mvAB $sep $pa $deltaMv $cmmnt\n";
    }

    print AN "$wdsId $dsc $aRa $aDec $mvAB $sep $pa $deltaMv $cmmnt\n";
  }
}

close AN;
close NF;
close NOTE;
close NRBY;
close NRRW;
close NR_SUS;
close PM;
close SPT;
close WDS;
close WIDE;

print "Of $wdsLineCt WDS pairs examined, $rejectCt were rejected.\n";
print "Done in ", sec2hms(time - $start), ". $cnfmdCt confirmed. ",
      "$nfCt pairs had no star found.\n";

sub byPipe {
  my @c = split /\|/, $a;
  my @d = split /\|/, $b;

  unless (($c[1] =~/\d/) and ($d[1] =~/\d/)) {
    print "P Sorting Error:  $c[1], $d[1].\n ^$a^\n ^$b^\n\n";
    return 0;
  } else {
    $c[1] <=> $d[1];
  }
}

# Get the square degree files that contain the area near the binary being
# checked.
sub getSD {
  my $fCt =  $_[0];
  my $minRa = $_[1];
  my $maxRa = $_[2];
  my $dec = $_[3];
  my $intMinRa = int($minRa * cos($dec) * $r2d);
  my $intMaxRa = int($maxRa * cos($dec) * $r2d);
  my $fDec = int(($dec * $r2d) + 90);

  if ($intMinRa == $intMaxRa) {
    $file[0] = "d_$fDec" . "_$intMinRa";
    $fCt = 1;
  } else {
    $file[0] = "d_$fDec" . "_$intMinRa";
    $file[1] = "d_$fDec" . "_$intMaxRa";
    $fCt = 2;
  }
  return $fCt;
}

            # unless ($m1 =~ /\d/) { #TEST
            #   print "$wdsLineCt) $dsc mva: $mva not numeric!\n"; #TEST
            #   last; #TEST
            # } #TEST

            # unless ($m2 =~ /\d/) { #TEST
            #   print "$wdsLineCt) $dsc mvb: $mvb not numeric!\n"; #TEST
            #   last; #TEST
            # } #TEST
