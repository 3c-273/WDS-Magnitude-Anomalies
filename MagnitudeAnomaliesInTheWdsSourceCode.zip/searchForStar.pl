#! /usr/bin/perl -w
# find a star in the data files.
use lib "/work/astro/utilities";
use astroUtils;
use strict;

my $start = time;

my $fCt = 0;
my $fndCt = 0;
my $ra = 0.0914283456452013;
my $dec = 1.1810206715932;
my $pi = 3.1415926535897932384626433;
my $r2d = 180 / 3.14159265358979323846;
my $sqDegDir= "/work/astro/wds/magnitudeStudy/squareDegrees";
my $tCt = 0;
my $tenArcSec = $pi / (180 * 360); # 10 arc seconds in radians.

my $minRa = $ra - $tenArcSec;
my $maxRa = $ra + $tenArcSec;
my $minDec = $dec - $tenArcSec;
my $maxDec = $dec + $tenArcSec;

my $data = "/work/astro/data";
my @catalog = qw(2MASS ppmxl tycho ucac4 urat1);
foreach my $ctlg (@catalog) {
  my $dir = "$data/$ctlg/naFormatData";

  opendir DIR, $dir or die "can't open $dir.\n";
  while (defined(my $file = readdir(DIR))) {
    my $df = "$dir/$file";
    unless (-f $df) { next; }

    $tCt++;

    unless (($file =~ /^d_156/) or ($file =~ /^d_157/) or ($file =~ /^d_158/)) {
      $fCt++;
      next;
    }

    open FILE, $df or die "can't open $df.\n";
    while (<FILE>) {
      my @a = split /\|/, $_;
      if (($a[0] < $maxRa) and ($a[0] > $minRa) and ($a[1] > $minDec) and
          ($a[1] < $maxDec)) {
        my $dRa = $ra - $a[0];
        my $dDec = $dec - $a[1];
        my $r = sqrt(($dRa * $dRa) + ($dDec + $dDec));

        my $raFile = int(($a[0] * $r2d) * cos($a[1]));
        my $storageFile = "$sqDegDir/$file" . "_$raFile";

        print "$df:\n  ", r4($a[0] * $r2d), " ", r4($a[1] * $r2d),
              ", cat: $a[6], mv: $a[5]. Delta r: ", r1($r * $r2d * 3600),
              " arc seconds.\n  Storing to $storageFile.\n";
        $fndCt++;
        last;
      }
    }
    close FILE;
  }
}
closedir DIR;

print "Of $tCt files, $fCt files were checked, ",
      "and the star was found in $fndCt files.\n";
print "Done in ", sec2hms(time - $start), ".\n";

# HJ_1018:
# my $maxDec = 1.18131155980193;
# my $minDec = 1.1807297833846;
# my $maxRa = 0.0921938793951636;
# my $minRa = 0.090662811895239;
