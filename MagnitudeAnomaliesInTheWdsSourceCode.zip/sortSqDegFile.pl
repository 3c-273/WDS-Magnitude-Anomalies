#! /usr/bin/perl -w
# Sort all of the files in squareDegrees by RA.

use lib "/work/astro/utilities";

use astroUtils;
use strict;

$| = 1;
my $start = time;

my $fCt = 0;
my $tmpDir = "/work/astro/wds/magnitudeStudy/tmp";
my $sqDegDir = "/work/astro/wds/magnitudeStudy/squareDegrees";
opendir DIR, $sqDegDir or die "can't open this directory.\n";
while (defined(my $file = readdir(DIR))) {
  my $df = "$sqDegDir/$file";
  unless (-f $df) { next; }

  my @a;
  open FILE, $df or die "can't open $df.\n";
  while (<FILE>) {
    push @a, $_;
  }
  close FILE;

  my @b =  sort byPipe @a;

  my $sortedFile = "$tmpDir/$file"; 
  open SRTD, ">$sortedFile" or die "Can't open $sortedFile.\n";
  foreach my $i (@b) { print SRTD $i; }
  close SRTD;

  $fCt++;
  if (($fCt % 100) == 0) { print "", ($fCt / 100), " "; }
}
closedir DIR;

print "\nDone in ", sec2hms(time - $start), "/n";

sub byPipe {
  my @c = split /\|/, $a;
  my @d = split /\|/, $b;

  unless (($c[0] =~/\d/) and ($d[0] =~/\d/)) {
    print "P Sorting Error:  $c[0], $d[0].\n ^$a^\n ^$b^\n\n";
    return 0;
  } else {
    $c[0] <=> $d[0];
  }
}

