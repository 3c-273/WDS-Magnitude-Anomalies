#! /usr/bin/perl -w
# Make a list of all objects in the PPMXL, Tycho, UCAC4, and URAT1 catalogs.
# All coordinates are J2000.
# 2MASS format:
# ra|dec|R|G|B|mv|Catalog|Name|jmv|hmv|kmv|Ouality|Blend|Proximity|Date|
# 0   1  2 3 4 5     6     7    8   9  10    11     12      13      14
# PPMXL format:
# ra|dec|R|G|B|mv|Catalog|Name|mvb|jmv|hmv|kmv|PM RA|PM Dec|pmRaErr|pmDecErr
# 0   1  2 3 4 5     6     7    8   9  10  11   12     13      14     15
# Tycho format:
# ra|dec|R|G|B|mv|Catalog|Name|mvb|pmRa|pmDec|pmFlag|
# 0   1  2 3 4 5     6     7    8   9    10     11
# UCAC4 format:
# ra|dec|R|G|B|mv|Catalog|Name|mvb|pmRa|pmDec|pmFlag|UCAC4 status.
# 0   1  2 3 4 5     6     7    8   9    10     11     12
# URAT1 format:
# ra|dec|R|G|B|mv|Catalog|Name|mvb|pmRa|pmDec|pmFlag|2MASS status|APASS status
# 0   1  2 3 4 5     6     7    8    9    10    11        12           13
#
# This program produces a series of files, each about a square degree in size
# with the following format:
# ra|dec|mv|Catalog|Name|mvB|pmRa|pmDec|pmStatus|jmv|hmv|kmv
# 0   1  2     3     4    5   6     7      8      9  10  11

use lib "/work/astro/utilities";

use astroUtils;
use strict;

my $data = "/work/astro/data";
my $r2d = 180 / 3.1415926535897932384626433;   # Radians to degrees.
my $sCt = 0;                                   # Star count.
my $start = time;

# 
my $sqDegDir= "/work/astro/wds/magnitudeStudy/squareDegrees";
opendir DIR, $sqDegDir or die "Can't open $sqDegDir.\n";
while (my $file = readdir(DIR)) {
  if (-f $file) { unlink $file; }
}
closedir DIR;

my ($ra, $dec, $cat, $mv, $mvb, $name, $jmv, $hmv, $kmv,
    $pmRa, $pmDec, $pmStatus);
my @catalog = qw(2MASS ppmxl tycho ucac4 urat1);
foreach my $ctlg (@catalog) {
  my $dir = "$data/$ctlg/naFormatData";

  print "Parsing $dir.\n"; #TEST

  opendir DIR, $dir or die "Can't open $dir!\n";
  while (defined(my $file = readdir DIR)) {
    my $fullPathFile = "$dir/$file";
    unless ((-f $fullPathFile) and ($file =~ /^d_/)) {
      # print "Ignoring $fullPathFile\n"; #TEST
      next;
    }

    open TXT, $fullPathFile or die "Can't open $fullPathFile!\n";

    # print "Reading $fullPathFile.\n"; #TEST

    while (<TXT>) {
      chomp $_;
      my @data = split /\|/, $_;
      $ra = $data[0];
      $dec = $data[1];
      $mv = $data[5];
      $mvb = $data[8];
      $name = $data[7];
      if ($ctlg eq "2MASS") {
        $cat = "2";
        $jmv = $data[8];
        $hmv = $data[9];
        $kmv = $data[10];
        $pmRa = "None";
        $pmDec = "None";
        $pmStatus = "None";
      } elsif ($ctlg eq "ppmxl") {
        $cat = "P";
        $jmv = $data[9];
        $hmv = $data[10];
        $kmv = $data[11];
        $pmRa = $data[12];
        $pmDec = $data[13];
        $pmStatus =  "$data[14]/$data[15]";
      } elsif ($ctlg eq "urat1") {
        $cat = "Z";
        $jmv = "None";
        $hmv = "None";
        $kmv = "None";
        $pmRa = $data[9];
        $pmDec = $data[10];
        $pmStatus = $data[11];
      } elsif ($ctlg eq "ucac4") {
        $cat = "U";
        $jmv = "None";
        $hmv = "None";
        $kmv = "None";
        $pmRa = $data[9];
        $pmDec = $data[10];
        $pmStatus = $data[12];
      } else  { # Tycho.
        $cat = "T";
        $jmv = "None";
        $hmv = "None";
        $kmv = "None";
        $pmRa = $data[9];
        $pmDec = $data[10];
        $pmStatus = $data[11];
      }
      
      my $line = "$ra|$dec|$mv|$cat|$name|$mvb|$pmRa|$pmDec|$pmStatus|" .
                 "$jmv|$hmv|$kmv\n";

      my $raFile = int(($ra * $r2d) * cos($dec));
      my $storageFile = "$sqDegDir/$file" . "_$raFile";

      # print "Saving to $storageFile.\n"; #TEST

      open SAVE, ">>$storageFile" or die "Can't open $storageFile.\n";
      print SAVE $line;
      close SAVE;
      # if ($sCt++ > 999) { print "Ending early"; exit; } #TEST
      $sCt++;
    }
    close TXT;
  }
  closedir DIR;
}

print "Done in ", sec2hms(time - $start), "\n"; 
