#! /usr/bin/perl
# From the large file of anomalous WDS magnitudes, nearbyAnomalies.txt, make a
# file of Id and positions of HTML data in a larger file the program creates,
# anomalies.web.

use strict;

my $dir = "/work/astro/wds/magnitudeStudy/results";
my $indx = "$dir/anomalies.ind";
open INDX, ">$indx" or die "Can't open $indx.\n";
my $web = "$dir/anomalies.web";
open WEB, ">$web" or die "Can't open $web.\n";

my $nrbyAn = "$dir/nearbyAnomalies.txt";
open NRAN, $nrbyAn or die "Can't open $nrbyAn.\n";
my $id = readline NRAN; # Save the 2nd line.
$id =~ s/\s+//g;
my $oldBTotal = 0;
my $bTotal = 0;
my $catData = "";
my $lCt = 0;
while(<NRAN>) {
  if ($_ =~ /^\d+/) { 
    print INDX "$oldBTotal " . ($bTotal - $oldBTotal), " $id\n";
    $oldBTotal = $bTotal;
    print WEB $catData;
    $catData = "";
    $id = $_;
    $id =~ s/\s+//g;
  } elsif ($_ =~ /^\s+\w+/) {
    my $t = length($_);
    my $cat = substr($_, 2, 5);
    my $id =  substr($_, 8, 20); 
    $id =~ s/\s+$//;
    my $coord =  substr($_, 28, 24);
    $coord =~ s/\s+$//;
    my $cmv =  substr($_, 53, 6);
    $cmv =~ s/\s+$//;
    my $r =  substr($_, 61, 5);
    $r =~ s/\s+$//;

    if ($cat !~ /\w/) { print "No catalog for ", length($_), ", $t, $_\n"; }
    
    my $data = "<TR><TD><FONT COLOR=lime><center>$cat</center></FONT></TD>\n" .
               "<TD><FONT COLOR=lime><center>$id</center></FONT></TD>\n" .
               "<TD><FONT COLOR=lime><center>$coord</center></FONT></TD>\n" .
               "<TD><FONT COLOR=lime><center>$cmv</center></FONT></TD>\n" .
               "<TD><FONT COLOR=lime><center>$r</center></FONT></TD></TR>\n\n";
    $bTotal += length($data);
    $catData .= $data;
  }

  # if ($lCt++ > 1000) { last; } #TEST
  $lCt++;
}
close INDX;
close NRAN;
close WEB;

print "Parsed $lCt lines.\n";
